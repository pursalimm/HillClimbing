﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HClim
{
    public partial class HClim : Form
    {
        public int n;
        public Label[] lb;
        public TextBox[,] tb;
        Point s, d;
        Random r = new Random();
        public char[,] minState = null;
        public char[,] State = null;
        public int Grade = 0;
        public int level = 0;

        public HClim()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void txtWMatrix_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsDigit(e.KeyChar))
                e.Handled = false;
            else
                e.Handled = true;
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            int Count = 0;
            if (txtWMatrix.Text != "" && int.Parse(txtWMatrix.Text) <= 16 && int.Parse(txtWMatrix.Text) % 2 == 0)
            {
                txtRow.Text = "";
                for (int i = 0; i < n; i++)
                    MatrixPanel.Controls.Remove(lb[i]);
                for (int i = 0; i < n * n; i++)
                    tableLayout.Controls.Clear();
                tableLayout.Visible = true;
                txtRow.Visible = true;
                n = int.Parse(txtWMatrix.Text);
                tb = new TextBox[n, n];
                lb = new Label[n];
                tableLayout.ColumnCount = n;
                tableLayout.RowCount = n;
                tableLayout.Height = n * 32;
                tableLayout.Width = n * 31;
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        tb[i, j] = new TextBox();
                        tb[i, j].Font = new Font("Tahoma", 10, FontStyle.Bold);
                        tb[i, j].Size = new Size(23, 23);
                        tb[i, j].ForeColor = Color.Red;
                        tb[i, j].Name = "T" + Convert.ToString(i);
                        tableLayout.Controls.Add(tb[i, j]);
                        Count++;
                        if (((i % 2) == 0) && (Count % 2 == 0) || ((i % 2) != 0) && (Count % 2 != 0))
                        {
                            tb[i, j].BackColor = Color.Black;
                            tb[i, j].ForeColor = Color.Red;
                        }
                    }
                    txtRow.Text += Convert.ToString(i + 1) + "\r\n\n";
                }

                int space = tableLayout.Width / n;
                int x = 39;
                for (int i = 0; i < n; i++)
                {
                    lb[i] = new Label();
                    lb[i].AutoSize = true;
                    lb[i].RightToLeft = RightToLeft.No;
                    lb[i].Font = new Font("Tahoma", 9, FontStyle.Bold);
                    lb[i].Name = "L" + Convert.ToString(i);
                    lb[i].Text = Convert.ToString(i + 1);
                    lb[i].Location = new System.Drawing.Point(x, 10);
                    MatrixPanel.Controls.Add(lb[i]);
                    x += space;
                }
                for (int i = 0; i < n; i++)
                    tb[r.Next(0, n-1), i].Text = " ۩";
                //Reset();
            }
            else
            {
                MessageBox.Show("مساله پیشنهادی شما فاقد جواب بهینه می باشد ، لطفا عدد ورودی را مضربی از 2 وارد نمائید");
                return;
            }
        }

        public void Reset()
        {
            State = new char[n, n];
            for (int i = 0; i < n; i++)
                for (int j = 0; j < n; j++)
                    State[i, j] = '0';

            for (int i = 0; i < n; i++)
            {
                int rand = r.Next(0, n-1);
                State[i, rand] = '۩';
                tb[rand, i].Text = " ۩";
            }
        }

        private void ExecuteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            richText.Clear();
            level = 0;
            minState = new char[n, n];
            Reset();
            int tempmin = Gard();
            int min = Gard();
            while (true)
            {
                level += 1;
                for (int i = 0; i < n; i++)
                    for (int j = 0; j < n; j++)
                    {
                        MoveQ(i);
                        Gard();
                        if (min > Grade)
                        {
                            tempmin = Grade;
                            for (int x = 0; x < n; x++)
                                for (int y = 0; y < n; y++)
                                    minState[x, y] = State[x, y];
                        }
                    }
                for (int x = 0; x < n; x++)
                    for (int yy = 0; yy < n; yy++)
                        State[x, yy] = minState[x, yy];
                if (tempmin < min)
                    min = tempmin;
                else
                {
                    if (min == 0)
                        MessageBox.Show("مساله دارای جواب بهینه مقابل می باشد");
                    else
                        MessageBox.Show("مساله موردنظر فاقد جواب بهینه می باشد , لطفا مساله دیگری را مطرح نمائید");
                    break;
                }
                richText.AppendText("Level : " + level + ", Min : " + min / 2 + "\r\n");
                for (int i = 0; i < n; i++)
                {
                    for (int j = 0; j < n; j++)
                    {
                        if (minState[i, j] == '۩')
                        {
                            tb[i, j].Text = " " + minState[i, j].ToString();
                            richText.AppendText("1");
                        }
                        else
                        {
                            tb[i, j].Text = "";
                            richText.AppendText("0");
                        }
                    }
                    richText.AppendText("\r\n");
                }
                richText.AppendText("\r\n");
            }
        }

        public void MoveQ(int xx)
        {
            s = new Point();
            d = new Point();
            s.Y = YPosition(xx);
            s.X = xx;
            if (s.Y == 0)
                d.Y = n - 1;
            else
                d.Y = s.Y - 1;
            d.X = s.X;
            State[d.X, d.Y] = '۩';
            State[s.X, s.Y] = '0';
        }

        private int YPosition(int xx)
        {
            for (int i = 0; i < n; i++)
                if (State[xx, i] == '۩')
                    return i;
            return -1;
        }

        public int Gard()
        {
            Grade = 0;
            for (int x = 0; x < n; x++)
                for (int y = 0; y < n; y++)
                    if (State[x, y] == '۩')
                    {
                        int i, j;
                        for (i = 0; i < n; i++)
                            if (State[i, y] == '۩')
                                Grade++;
                        Grade--;
                        i = x; j = y;
                        while (i >= 0 && j >= 0)
                        {
                            if (State[i, j] == '۩')
                                Grade++;
                            i--;
                            j--;
                        }
                        Grade--;
                        i = x; j = y;
                        while (i <= n - 1 && j <= n - 1)
                        {
                            if (State[i, j] == '۩')
                                Grade++;
                            i++;
                            j++;
                        }
                        Grade--;
                        i = x; j = y;
                        while (i >= 0 && j <= n - 1)
                        {
                            if (State[i, j] == '۩')
                                Grade++;
                            i--;
                            j++;
                        } Grade--;
                        i = x; j = y;
                        while (i <= n - 1 && j >= 0)
                        {
                            if (State[i, j] == '۩')
                                Grade++;
                            i++;
                            j--;
                        }
                        Grade--;
                    }
            return Grade;
        }

    }
}
